package com.example.orbital;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

public class OrbitalPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final int MAX_RING = 30;
    private static final int MAX_AMOUNT = 64;
    private static final double RING_SPACING = 2.5;
    private static final double SKY_HEIGHT = 25;

    private NamespacedKey keyType;
    private NamespacedKey keyRing;

    @Override
    public void onEnable() {
        keyType = new NamespacedKey(this, "orbital_type");
        keyRing = new NamespacedKey(this, "orbital_ring");
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("orbital");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    // ---------------- Command ----------------
    // /orbital give <player> nuke <ring> [amount]
    // /orbital give <player> stab [amount]
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("orbital.admin")) {
            sender.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage("§e/orbital give <player> nuke <ring> [จำนวน]");
            sender.sendMessage("§e/orbital give <player> stab [จำนวน]");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cไม่พบผู้เล่นออนไลน์ชื่อ " + args[1]);
            return true;
        }

        String type = args[2].toLowerCase();
        int ring = 0;
        int amount = 1;

        try {
            if (type.equals("nuke")) {
                if (args.length < 4) {
                    sender.sendMessage("§cใส่จำนวนวง: /orbital give <player> nuke <ring> [จำนวน]");
                    return true;
                }
                ring = Integer.parseInt(args[3]);
                if (args.length >= 5) amount = Integer.parseInt(args[4]);
            } else if (type.equals("stab")) {
                if (args.length >= 4) amount = Integer.parseInt(args[3]);
            } else {
                sender.sendMessage("§ctype ต้องเป็น nuke หรือ stab");
                return true;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage("§cต้องใส่ตัวเลขเท่านั้น");
            return true;
        }

        if (type.equals("nuke") && (ring < 1 || ring > MAX_RING)) {
            sender.sendMessage("§cring ต้องอยู่ระหว่าง 1-" + MAX_RING);
            return true;
        }
        if (amount < 1 || amount > MAX_AMOUNT) {
            sender.sendMessage("§cจำนวนต้องอยู่ระหว่าง 1-" + MAX_AMOUNT);
            return true;
        }

        for (int i = 0; i < amount; i++) {
            Map<Integer, ItemStack> left = target.getInventory().addItem(createRod(type, ring));
            for (ItemStack s : left.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), s);
            }
        }
        sender.sendMessage("§aให้ Orbital " + type + (ring > 0 ? " ring=" + ring : "")
                + " x" + amount + " กับ " + target.getName());
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.add("give");
        else if (a.length == 2) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        else if (a.length == 3) { out.add("nuke"); out.add("stab"); }
        else if (a.length == 4 && a[2].equalsIgnoreCase("nuke")) out.addAll(List.of("1", "5", "10", "20"));
        String last = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }

    // ---------------- Item ----------------
    private ItemStack createRod(String type, int ring) {
        ItemStack item = new ItemStack(Material.FISHING_ROD);
        ItemMeta meta = item.getItemMeta();
        if (type.equals("nuke")) {
            meta.setDisplayName("§c§lOrbital Nuke Shot §7(ring " + ring + ")");
        } else {
            meta.setDisplayName("§b§lOrbital Stab Shot");
        }
        meta.setLore(List.of("§7คลิกขวาเพื่อยิงไปยังจุดที่เล็ง", "§7ใช้ครั้งเดียวแล้วแตก"));
        meta.getPersistentDataContainer().set(keyType, PersistentDataType.STRING, type);
        meta.getPersistentDataContainer().set(keyRing, PersistentDataType.INTEGER, ring);
        item.setItemMeta(meta);
        return item;
    }

    // ---------------- Use ----------------
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.FISHING_ROD || !item.hasItemMeta()) return;

        var pdc = item.getItemMeta().getPersistentDataContainer();
        String type = pdc.get(keyType, PersistentDataType.STRING);
        if (type == null) return;

        e.setCancelled(true); // กันไม่ให้เหวี่ยงเบ็ดจริง

        Player p = e.getPlayer();
        if (!p.hasPermission("orbital.use")) return;

        RayTraceResult r = p.getWorld().rayTraceBlocks(
                p.getEyeLocation(), p.getEyeLocation().getDirection(), 200,
                FluidCollisionMode.NEVER, true);
        if (r == null) {
            p.sendMessage("§cไม่พบจุดที่เล็ง (ไกลเกิน 200 บล็อก)");
            return;
        }
        Location center = r.getHitPosition().toLocation(p.getWorld());

        // เบ็ดแตก = ใช้หมดไป 1 อัน
        item.setAmount(item.getAmount() - 1);
        p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);

        if (type.equals("nuke")) {
            int ring = pdc.getOrDefault(keyRing, PersistentDataType.INTEGER, 1);
            strikeNuke(p, center, ring);
        } else {
            strikeStab(p, center);
        }
    }

    // ---------------- Strikes ----------------
    private void strikeNuke(Player owner, Location center, int rings) {
        for (int r = 1; r <= rings; r++) {
            final int ringIndex = r;
            // วงในลงก่อน วงนอกตามมา
            Bukkit.getScheduler().runTaskLater(this, () -> spawnRing(owner, center, ringIndex), (long) (r - 1) * 4);
        }
    }

    private void spawnRing(Player owner, Location center, int r) {
        double radius = r * RING_SPACING;
        int count = Math.max(6, (int) Math.round(2 * Math.PI * radius / RING_SPACING));
        for (int i = 0; i < count; i++) {
            double ang = 2 * Math.PI * i / count;
            Location loc = center.clone().add(Math.cos(ang) * radius, SKY_HEIGHT, Math.sin(ang) * radius);
            spawnTnt(owner, loc, 50, new Vector(0, -0.5, 0));
        }
    }

    private void strikeStab(Player owner, Location center) {
        // เสา TNT พุ่งทิ่มลงมาตรงจุดเดียว
        for (int i = 0; i < 20; i++) {
            Location loc = center.clone().add(0, SKY_HEIGHT + i * 1.2, 0);
            spawnTnt(owner, loc, 45, new Vector(0, -2.0, 0));
        }
    }

    private void spawnTnt(Player owner, Location loc, int fuse, Vector vel) {
        TNTPrimed tnt = loc.getWorld().spawn(loc, TNTPrimed.class);
        tnt.setFuseTicks(fuse);
        tnt.setSource(owner);
        tnt.setVelocity(vel);
    }
}
